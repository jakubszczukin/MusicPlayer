package com.example.musicplayer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var listView = R.id.songListView

        ExcuseMe.couldYouHandlePermissionsForMe(this){ accept -> if(accept) openMusicPlayer() }

    }

    private fun openMusicPlayer(){

    }
}